﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GOT
{
    class GOT
    {
        public string Character { get; set; }
        public string Quote { get; set;  }

        public GOT()
        {
            Character = "";
            Quote = "";
        }

    }
}
